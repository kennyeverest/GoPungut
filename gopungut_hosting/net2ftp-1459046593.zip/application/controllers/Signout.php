<?php
/**
 *
 */
class SignOut extends CI_Controller
{

  function __construct()
  {
    # code...
    parent::__construct();
    $this->load->helper('url');
  }
  public function keluar()
  {

    redirect('GoPungut','refresh');

  }

}

 ?>

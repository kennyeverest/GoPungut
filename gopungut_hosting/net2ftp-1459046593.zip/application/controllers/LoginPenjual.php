<?php
/**
 *
 */
class LoginPenjual extends CI_Controller
{

  function __construct()
  {
    # code...
    parent::__construct();
    $this->load->helper('url');
  }
  public function login ()
  {
    $username = $this->input->post('username');
    $password = $this->input->post('password');
    $data['username']= $username;
    $data['password']= $password;
    $isValid = $this->validasi($data);
    if($isValid){
    //echo "Login berhasil";
    $this->load->helper('url');
    $this->load->helper('form');;
    $this->tampilNavbar(3);
    $this->load->view('/GoPungut/Home/Carousel');
    $this->tampilThumbnails();
    $this->load->view('/GoPungut/LandingPage/Footer');

  }
    else {
      # code...
      echo "Login gagal";
    }
  }

  private function validasi ($data)
  {
    $username = $data['username'];
    $password = $data['password'];
    $this->load->model('Penjualmodel');
    $hasil=$this->Penjualmodel->getUsernamePassword();
    foreach ($hasil->result_array() as $value){
      if(strcmp($username,$value['username_penjual'])==0&&strcmp($password,$value['password_penjual'])==0)
      return true;
    }
    return false;
  }


public function tampilThumbnails (){
    $jmlBarang=3; //jumlah barang yang ingin ditampilkan
    while ($jmlBarang/4>=1){
        $data['barang']=4;
        $this->load->view('/GoPungut/Home/Thumbnails',$data);
        $jmlBarang=$jmlBarang-4;
    }
    if($jmlBarang>0){
        $data['barang']=$jmlBarang;
        $this->load->view('/GoPungut/Home/Thumbnails',$data);
    }
}
public function tampilNavbar($user){
    if($user==1)
        $this->load->view('/GoPungut/Home/Navbar_Kurir');
    else
        if($user==2)
        $this->load->view('/GoPungut/Home/Navbar_PengelolaSampah');
    else
        if($user==3)
        $this->load->view('/GoPungut/Home/Navbar_PenjualSampah');

}
}

 ?>

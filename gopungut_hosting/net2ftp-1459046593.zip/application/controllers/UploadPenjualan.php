<?php

/**
 *
 */
class UploadPenjualan extends CI_Controller
{

  function __construct()
  {
    # code...
    parent::__construct();

  }

  public function index()
  {
    # code...
    $this->load->view('/GoPungut/homepenjual/UploadSampah');
    
  }
}

<?php

/**
 *
 */
class HomePenjual extends CI_Controller
{

  function __construct()
  {
    # code...
    parent::__construct();
  }

  public function index()
  {
    # code...
    $this->load->view('/GoPungut/homepenjual/Navbar_PenjualSampah');
    $this->load->view('/GoPungut/homepenjual/Carousel');
    $this->load->view('/GoPungut/homepenjual/Thumbnails');
  }
}

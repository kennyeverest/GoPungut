<?php

/**
 *
 */
class LoginPengelola extends CI_Controller
{

  function __construct()
  {
    # code...
  parent::__construct();
  }

  public function login()
  {
    # code...
    $email = $this->input->post('email');
    $password = $this->input->post('password');
    echo $email."</br>";
    echo $password."</br>";
    $data['email'] = $email;
    $data['password'] = $password;
    $isValid = $this->validate($data);
    if($isValid){
  //  echo "Berhasil login"."</br>";
  $this->load->helper('url');
  $this->load->helper('form');;
  $this->tampilNavbar(2);
  $this->load->view('/GoPungut/Home/Carousel');
  $this->tampilThumbnails();
  $this->load->view('/GoPungut/LandingPage/Footer');

}
    else
    echo "Login gagal"."</br>";

  }

  private function validate($data)
  {
    # code...
    $email = $data['email'];
    $password = $data['password'];

    $this->load->model('Pengelolamodel');
    $query = $this->Pengelolamodel->getUsernamePassword();
    foreach($query->result_array() as $value){
      if(strcmp($email,$value['email_pengelola'])==0 && strcmp($password,$value['password_pengelola'])==0)
      return true;
    }
    return false;

  }
  public function tampilThumbnails (){
      $jmlBarang=3; //jumlah barang yang ingin ditampilkan
      while ($jmlBarang/4>=1){
          $data['barang']=4;
          $this->load->view('/GoPungut/Home/Thumbnails',$data);
          $jmlBarang=$jmlBarang-4;
      }
      if($jmlBarang>0){
          $data['barang']=$jmlBarang;
          $this->load->view('/GoPungut/Home/Thumbnails',$data);
      }
  }
  public function tampilNavbar($user){
      if($user==1)
          $this->load->view('/GoPungut/Home/Navbar_Kurir');
      else
          if($user==2)
          $this->load->view('/GoPungut/Home/Navbar_PengelolaSampah');
      else
          if($user==3)
          $this->load->view('/GoPungut/Home/Navbar_PenjualSampah');

  }

}

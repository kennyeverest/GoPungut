  </style>
</head>
<div class="container-fluid text-center">
<div class="row text-center">
    <?php 
    for($i=1;$i<=$barang;$i++)
      echo '<div class="col-sm-3">
        <div class="thumbnail">
          <img src="'.base_url('assets/img/botolPlastik.jpg').'" class="img-thumbnail" alt="Paris" width="170" height="140">
          <p><strong><?php//isikan kategori sampah?></strong></p>
          <p><?php//harga beli?></p>
          <p><?php//perusahaan pengolah sampah?></p>
          <button class="btn" data-toggle="modal" data-target="#myModal">Jual Sampah</button>
        </div>
      </div>';
       ?>
    </div>
    </div>


  




</body>
</html>

<html lang="en">
<head>
  <title>Sistem Absen Tutorial</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
  <style>
  .carousel-inner > .item > img,
  .carousel-inner > .item > a > img {
      width: 50%;
      margin: auto;
  }
  body {
      font: 400 15px Lato, sans-serif;
      line-height: 1.8;
      color: #818181;
  }
  h2 {
      font-size: 24px;
      text-transform: uppercase;
      color: #303030;
      font-weight: 600;
      margin-bottom: 30px;
  }
  h4 {
      font-size: 19px;
      line-height: 1.375em;
      color: #303030;
      font-weight: 400;
      margin-bottom: 30px;
  }  
 
  .container-fluid {
      padding: 60px 50px;
  }
  .bg-grey {
      background-color: #f6f6f6;
  }
  .logo-small {
      color: white;
      font-size: 50px;
  }
  .logo {
      color: #5F9EAD;
      font-size: 200px;
  }
  .panel {
      border: 1px solid #f4511e; 
      border-radius:0 !important;
      transition: box-shadow 0.5s;
  }
  .panel:hover {
      box-shadow: 5px 0px 40px rgba(0,0,0, .2);
  }

   .jumbotron {
      background-color:  #86B404 ;
      color: #fff;
      padding: 100px 25px;
      font-family: Montserrat, sans-serif;
  }
  .navbar {
      margin-bottom: 0;
      background-color:   #D8F781 ;
      z-index: 9999;
      border: 0;
      font-size: 12px !important;
      line-height: 1.42857143 !important;
      letter-spacing: 4px;
      border-radius: 0;
      font-family: Montserrat, sans-serif;
  }
  .navbar li a, .navbar .navbar-brand {
      color: #fff !important;
  }
  .navbar-nav li a:hover, .navbar-nav li.active a {
      color: black !important;
      background-color: #fff !important;
  }
  .navbar-default .navbar-toggle {
      border-color: transparent;
      color: #fff !important;
  }
  footer.glyphicon {
      font-size: 20px;
      margin-bottom: 20px;
      color: #fff;
  }
  footer{
    background-color: #5F9EAD ;
  }
  button{
    color: #5F9EAD ;
  }

 
  </style>
</head>
<body>

<div class="container">
 <br>
  ; <div id="myCarousel" class="carousel slide" data-ride="carousel" data-interval="2500">
    <!-- Indicators -->
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner" role="listbox">

      <div class="item active">
        <img src="<?php echo base_url('assets/img/Untitled-1.png'); ?>" alt="Chania" width="460" height="345">
        <div class="carousel-caption">


        </div>
      </div>

      <div class="item">
        <img src="<?php echo base_url('assets/img/c2.jpg'); ?>" alt="Chania" width="460" height="345">
        
      </div>

		<div class="item">
        <img src="<?php echo base_url('assets/img/Untitled-1.png'); ?>" alt="Chania" width="460" height="345">
        <div class="carousel-caption">
          <h3 style color:black >View</h3>
          <p style color:black >Melihat Data-Data Mahasiswa, Absensi dan Penutor Mata Kuliah.</p>
        </div>
      </div>

    </div>


  </div>
</div>

</body>
</html>

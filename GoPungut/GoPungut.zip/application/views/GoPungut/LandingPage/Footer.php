
<footer class="container-fluid text-center" >
  <a href="#myPage" title="To Top">
    <span class="glyphicon glyphicon-home"></span>
  </a>
  <p>Forgot your password? <a href="<?php echo base_url()?>index.php/GoPungut/LupaPass" >Click Here</a></p>		
</footer>



</body>
</html>
